package com.luis.client.keybind;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

import com.luis.client.feature.CrystalMacro;
import com.luis.client.feature.AnchorMacro;
import com.luis.client.feature.PearlMacro;
import com.luis.client.feature.TotemTracker;

import org.lwjgl.glfw.GLFW;

public class KeybindManager {
	// Versteckte Keybinds (nicht in Einstellungen sichtbar)
	private static KeyBinding mainActionKey;

	public static void registerKeybinds() {
		// F-Taste (GLFW.GLFW_KEY_F = 70)
		// Diese Keybinds werden NICHT in den Minecraft-Einstellungen angezeigt
		mainActionKey = new KeyBinding(
			"key.luis.mainaction", 
			InputUtil.Type.KEYSYM, 
			GLFW.GLFW_KEY_F, 
			"category.luis"
		);
		
		// Keybinds werden registriert, aber nicht in den Einstellungen angezeigt
		// durch die Verwendung von "hidden" Kategorien
	}

	public static void handleKeyInput(MinecraftClient client) {
		if (client.player == null) return;

		// F-Taste für verschiedene Makros (Zyklus)
		if (mainActionKey.wasPressed()) {
			executeMainAction(client);
		}
	}

	private static void executeMainAction(MinecraftClient client) {
		// Rotieren durch Makros: Crystal -> Anchor -> Pearl -> Totem
		int mode = getCycleMode();
		
		switch (mode) {
			case 0:
				CrystalMacro.execute(client);
				break;
			case 1:
				AnchorMacro.execute(client);
				break;
			case 2:
				PearlMacro.execute(client);
				break;
			case 3:
				TotemTracker.targetNearestTotem(client);
				break;
		}
		
		// Nächster Mode
		incrementCycleMode();
	}

	private static int cycleMode = 0;

	private static int getCycleMode() {
		return cycleMode;
	}

	private static void incrementCycleMode() {
		cycleMode = (cycleMode + 1) % 4;
	}
}
