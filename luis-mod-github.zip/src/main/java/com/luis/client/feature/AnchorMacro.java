package com.luis.client.feature;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;

public class AnchorMacro {
	private static long lastExecutionTime = 0;
	private static final long COOLDOWN_MS = 50; // 50ms zwischen Clicks

	public static void execute(MinecraftClient client) {
		if (client.player == null || client.world == null) return;

		long currentTime = System.currentTimeMillis();
		if (currentTime - lastExecutionTime < COOLDOWN_MS) {
			return;
		}

		PlayerEntity player = client.player;

		// Suche nach Respawn Anchor im Sichtfeld
		if (client.crosshairTarget instanceof BlockHitResult blockHit) {
			var blockState = client.world.getBlockState(blockHit.getBlockPos());
			
			// Prüfe ob es ein Respawn Anchor ist
			if (blockState.getBlock().getName().getString().contains("respawn_anchor")) {
				// Interaktion mit dem Anchor (Zünden/Aktivieren)
				if (client.interactionManager != null) {
					client.interactionManager.interactBlock(
						player, 
						client.world, 
						Hand.MAIN_HAND, 
						blockHit
					);
				}
			}
		}

		lastExecutionTime = currentTime;
	}
}
