package com.luis.client.feature;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

public class CrystalMacro {
	private static long lastExecutionTime = 0;
	private static final long COOLDOWN_MS = 50; // 50ms zwischen Clicks

	public static void execute(MinecraftClient client) {
		if (client.player == null || client.world == null) return;

		long currentTime = System.currentTimeMillis();
		if (currentTime - lastExecutionTime < COOLDOWN_MS) {
			return;
		}

		PlayerEntity player = client.player;

		// End Crystal im Inventory finden
		int crystalSlot = findCrystalInInventory(player);
		if (crystalSlot == -1) return;

		// Zum Crystal-Slot wechseln
		int previousSlot = player.getInventory().selectedSlot;
		player.getInventory().selectedSlot = crystalSlot;

		// Block unter dem Spieler finden
		HitResult hitResult = client.crosshairTarget;
		if (hitResult instanceof BlockHitResult blockHit) {
			// Platzieren
			if (client.interactionManager != null) {
				client.interactionManager.interactBlock(player, client.world, Hand.MAIN_HAND, blockHit);
				client.interactionManager.attackBlock(blockHit.getBlockPos(), blockHit.getSide());
			}
		}

		// Zurück zum vorherigen Slot
		player.getInventory().selectedSlot = previousSlot;

		lastExecutionTime = currentTime;
	}

	private static int findCrystalInInventory(PlayerEntity player) {
		for (int i = 0; i < player.getInventory().size(); i++) {
			ItemStack stack = player.getInventory().getStack(i);
			if (stack.getItem() == Items.END_CRYSTAL && !stack.isEmpty()) {
				return i;
			}
		}
		return -1;
	}
}
