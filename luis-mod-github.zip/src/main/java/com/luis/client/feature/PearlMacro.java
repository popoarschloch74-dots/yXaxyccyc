package com.luis.client.feature;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

public class PearlMacro {
	private static long lastExecutionTime = 0;
	private static final long COOLDOWN_MS = 100; // 100ms zwischen Pearl-Würfen (Cooldown)

	public static void execute(MinecraftClient client) {
		if (client.player == null || client.world == null) return;

		long currentTime = System.currentTimeMillis();
		if (currentTime - lastExecutionTime < COOLDOWN_MS) {
			return;
		}

		PlayerEntity player = client.player;

		// Enderpearl im Inventory finden
		int pearlSlot = findPearlInInventory(player);
		if (pearlSlot == -1) return;

		// Zum Pearl-Slot wechseln
		int previousSlot = player.getInventory().selectedSlot;
		player.getInventory().selectedSlot = pearlSlot;

		// Pearl werfen
		if (client.interactionManager != null) {
			client.interactionManager.attackBlock(
				player.getBlockPos(), 
				null
			);
			
			// Alternative: Use Action für Pearl
			client.interactionManager.clickCreativeStack(
				player.getStackInHand(Hand.MAIN_HAND), 
				36 + pearlSlot
			);
		}

		// Zurück zum vorherigen Slot
		player.getInventory().selectedSlot = previousSlot;

		lastExecutionTime = currentTime;
	}

	private static int findPearlInInventory(PlayerEntity player) {
		for (int i = 0; i < player.getInventory().size(); i++) {
			ItemStack stack = player.getInventory().getStack(i);
			if (stack.getItem() == Items.ENDER_PEARL && !stack.isEmpty()) {
				return i;
			}
		}
		return -1;
	}
}
