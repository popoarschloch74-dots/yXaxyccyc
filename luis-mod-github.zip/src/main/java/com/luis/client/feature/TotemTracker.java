package com.luis.client.feature;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.Items;
import net.minecraft.world.World;

public class TotemTracker {
	private static ItemEntity nearestTotem = null;
	private static final double DETECTION_RANGE = 16.0; // 16 Blöcke Reichweite

	public static void updateTotems(World world) {
		if (world == null) return;

		nearestTotem = null;
		double nearestDistance = Double.MAX_VALUE;

		// Suche nach sichtbaren Totem-Items in der Nähe
		for (Entity entity : world.getEntities()) {
			if (entity instanceof ItemEntity itemEntity) {
				if (itemEntity.getStack().getItem() == Items.TOTEM_OF_UNDYING) {
					double distance = itemEntity.distanceTo(
						MinecraftClient.getInstance().player
					);

					if (distance < DETECTION_RANGE && distance < nearestDistance) {
						nearestTotem = itemEntity;
						nearestDistance = distance;
					}
				}
			}
		}
	}

	public static void targetNearestTotem(MinecraftClient client) {
		if (client.player == null || nearestTotem == null) {
			return;
		}

		// Maus zum Totem ziehen
		double dx = nearestTotem.getX() - client.player.getX();
		double dy = nearestTotem.getY() - client.player.getY();
		double dz = nearestTotem.getZ() - client.player.getZ();

		// Rotation berechnen
		double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
		if (distance == 0) return;

		float yaw = (float) Math.atan2(dz, dx) * 180.0f / (float) Math.PI - 90.0f;
		float pitch = (float) -Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0f / (float) Math.PI;

		// Player-Rotation setzen (Kopf folgt dem Totem)
		client.player.setYaw(yaw);
		client.player.setPitch(pitch);

		// Optional: Automatisch aufsammeln wenn in Reichweite
		if (distance < 2.0) {
			// Spieler wird automatisch das Item aufsammeln (default Minecraft-Verhalten)
		}
	}

	public static ItemEntity getNearestTotem() {
		return nearestTotem;
	}
}
