package com.luis.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientEntityEvents;

import com.luis.LuisMod;
import com.luis.client.keybind.KeybindManager;
import com.luis.client.feature.CrystalMacro;
import com.luis.client.feature.AnchorMacro;
import com.luis.client.feature.PearlMacro;
import com.luis.client.feature.TotemTracker;

@Environment(EnvType.CLIENT)
public class LuisClient implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		LuisMod.LOGGER.info("Luis Client wird initialisiert!");

		// Keybinds registrieren
		KeybindManager.registerKeybinds();

		// Event-Listener registrieren
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			KeybindManager.handleKeyInput(client);
		});

		ClientEntityEvents.ENTITY_LOAD.register((entity, world) -> {
			TotemTracker.updateTotems(world);
		});
	}
}
