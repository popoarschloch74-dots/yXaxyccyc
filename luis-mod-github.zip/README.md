# Luis Mod - Minecraft 1.21.1 Fabric

Eine legitime PvP-Utility-Mod für Minecraft 1.21.1 mit versteckten Keybinds.

## Features

✅ **Crystal-Makro** - Schnelles Platzieren von End Crystals  
✅ **Anchor-Makro** - Schnelles Zünden von Respawn Anchors  
✅ **Pearl-Makro** - Schnelles Werfen von Enderpearls  
✅ **Totem-Auto-Ziel** - Maus zieht zu sichtbaren Totems (nur sichtbare!)  
✅ **Versteckte Keybinds** - Nicht in den Minecraft-Einstellungen sichtbar

## Steuerung

**Haupttaste: F**
- 1. Druck: Crystal-Makro
- 2. Druck: Anchor-Makro
- 3. Druck: Pearl-Makro
- 4. Druck: Totem-Ziel

## Installation

### Voraussetzungen
- Java 21+
- Gradle
- Minecraft 1.21.1 Fabric

### Schritt 1: Build
```bash
./gradlew build
```

### Schritt 2: Mod installieren
Die kompilierte Mod findest du hier:
```
build/libs/luis-1.0.0.jar
```

Kopiere diese Datei in den `mods` Ordner deines Minecraft-Verzeichnisses:
```
.minecraft/mods/luis-1.0.0.jar
```

### Schritt 3: Fabric Launcher starten
- Starte Minecraft mit Fabric
- Die Mod erscheint im Mods-Menü

## Konfiguration

Die Keybinds können NICHT über die Minecraft-Einstellungen geändert werden.
Um die Keybinds anzupassen, bearbeite die `KeybindManager.java`:

```java
GLFW.GLFW_KEY_F  // Aktuelle Taste (F)
```

Verfügbare Tasten (GLFW-Codes):
- `GLFW.GLFW_KEY_G` = G
- `GLFW.GLFW_KEY_H` = H
- `GLFW.GLFW_KEY_J` = J
- `GLFW.GLFW_KEY_K` = K
- etc.

## Projekt-Struktur

```
luis/
├── build.gradle          # Build-Konfiguration
├── gradle.properties     # Gradle-Properties
├── src/main/
│   ├── java/com/luis/
│   │   ├── LuisMod.java              # Haupt-Mod Klasse
│   │   └── client/
│   │       ├── LuisClient.java       # Client-Init
│   │       ├── keybind/
│   │       │   └── KeybindManager.java
│   │       └── feature/
│   │           ├── CrystalMacro.java
│   │           ├── AnchorMacro.java
│   │           ├── PearlMacro.java
│   │           └── TotemTracker.java
│   └── resources/
│       ├── fabric.mod.json
│       └── luis.mixins.json
```

## Lizenz

MIT License

## Hinweise

- Diese Mod ist **nur für legitime PvP** gedacht
- Verwende sie verantwortungsvoll auf Servern
- Die Mod funktioniert nur im Client-Bereich
